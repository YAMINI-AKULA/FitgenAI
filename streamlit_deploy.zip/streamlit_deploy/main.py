import streamlit as st
from google.cloud import firestore
import vertexai
from vertexai.generative_models import GenerativeModel, GenerationConfig, HarmCategory, HarmBlockThreshold

from google.oauth2 import service_account

# Your GCP project and model configurations
PROJECT_ID = "fitgenai"
LOCATION = "us-central1"
MODEL_ID = "gemini-1.5-pro-001"

# Initialize Firestore client
client = firestore.Client()

# Initialize Vertex AI model
vertexai.init(project=PROJECT_ID, location=LOCATION)
model = GenerativeModel(MODEL_ID)

# Streamlit app
def main():
    st.title("FitGen AI")

    # Fetch data from Firestore
    collection_ref = client.collection('feedback_collection')
    documents = collection_ref.stream()
    recommendations_list = []
    for doc in documents:
        data = doc.to_dict()
        recommendations = data.get('recommendations', [])
        recommendations_list.extend(recommendations)

    # User input
    user_input = st.text_input("Meet your personalised fitness trainer powered by GEMINI")
    if st.button("Ask about how have you been working out!"):
        prompt = f"""
        User input: {user_input}
        
        Here are some posture tips from various analyses:
        {recommendations_list}
        
        Please analyze these tips and provide a comprehensive and personalized set of recommendations to improve posture based on the above suggestions.
        Answer:
        """


        # Generate content using Gemini
        response = model.generate_content(
            [prompt],
            generation_config=GenerationConfig(
                temperature=0.9,
                top_p=1.0,
                max_output_tokens=8192,
            ),
            safety_settings={
                HarmCategory.HARM_CATEGORY_HARASSMENT: HarmBlockThreshold.BLOCK_LOW_AND_ABOVE,
                HarmCategory.HARM_CATEGORY_HATE_SPEECH: HarmBlockThreshold.BLOCK_LOW_AND_ABOVE,
                HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT: HarmBlockThreshold.BLOCK_LOW_AND_ABOVE,
                HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT: HarmBlockThreshold.BLOCK_LOW_AND_ABOVE,
            },
        )

        # Display response
        st.write(f"Response:\n{response.text}")

if __name__ == "__main__":
    main()
