import logging
import vertexai
from google.cloud import storage, firestore
from vertexai.generative_models import GenerativeModel, Part
import vertexai.preview.generative_models as generative_models

# Configuration
PROJECT_ID = "fitgenai"
LOCATION = "us-central1"
MODEL_ID = "gemini-1.5-pro-001"  # Update with your Gemini model ID
MODEL = None

# Initialize Vertex AI for Gemini model
def init_model():
    global MODEL
    logging.info("Initializing Vertex AI model...")
    vertexai.init(project=PROJECT_ID, location=LOCATION)
    MODEL = GenerativeModel(MODEL_ID)
    logging.info("Model initialized successfully.")

# Function to generate recommendations using Gemini model
def generate_recommendations(image_uri):
    logging.info("Generating recommendations using Gemini model...")

    if MODEL is None:
        init_model()

    # Prepare the image and text input for Gemini model
    image = Part.from_uri(mime_type="image/jpeg", uri=image_uri)
    text = """for this image analyse the posture and give recommendations to correct it and provide feedback and improvements"""

    generation_config = {
        "max_output_tokens": 8192,
        "temperature": 1,
        "top_p": 0.95,
    }

    safety_settings = {
        generative_models.HarmCategory.HARM_CATEGORY_HATE_SPEECH: generative_models.HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
        generative_models.HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT: generative_models.HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
        generative_models.HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT: generative_models.HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
        generative_models.HarmCategory.HARM_CATEGORY_HARASSMENT: generative_models.HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
    }

    try:
        # Generate content using Gemini model
        responses = MODEL.generate_content([image, text], generation_config=generation_config, safety_settings=safety_settings, stream=True)
        recommendations = [response.text for response in responses]
        logging.info("Recommendations generated successfully.")
    except Exception as e:
        logging.error(f"Error generating recommendations: {e}")
        recommendations = []

    return recommendations

# Function to store feedback in Firestore
def store_feedback(file_name, recommendations):
    logging.info(f"Storing recommendations for {file_name} in Firestore")

    try:
        db = firestore.Client()
        # Save the recommendations in Firestore
        doc_ref = db.collection('feedback_collection').document(file_name)
        doc_ref.set({
            'file_name': file_name,
            'recommendations': recommendations,
            'timestamp': firestore.SERVER_TIMESTAMP
        })
        logging.info(f"Stored recommendations for {file_name} in Firestore successfully.")
    except Exception as e:
        logging.error(f"Error storing feedback: {e}")

# Cloud Function triggered by new file upload to Cloud Storage
def trigger_analysis(event, context):
    """Cloud Function triggered by Cloud Storage events."""
    logging.info(f"Function triggered by event: {event}")

    try:
        file = event
        bucket_name = file['bucket']
        file_name = file['name']
        logging.info(f"Processing image file: {file_name}")

        # Generate recommendations using Gemini
        image_uri = f"gs://{bucket_name}/{file_name}"
        recommendations = generate_recommendations(image_uri)

        # Store the recommendations in Firestore
        store_feedback(file_name, recommendations)

        logging.info("Processing completed.")
    except Exception as e:
        logging.error(f"Error in trigger_analysis function: {e}")
